<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Architecture rules

- Public raffle content lives in `src/routes/index.tsx` with in-page anchors; the only other route is `/admin`, a private panel (owner-created accounts only, signup disabled) — keeps the public site one page.
- Admin ticket edits go through `src/lib/admin.functions.ts` with `requireSupabaseAuth` + `has_role(admin)`; every auth user gets admin via trigger because public signup is off.
- Ticket state lives in Supabase table `public.boletos`; all access goes through `createServerFn` using the anon/publishable client from `src/lib/supabase-server.ts`. The public board reads the `boletos_tablero` view (number and status only) and reserves through the `apartar_boleto` function, which claims a ticket only while it is still free; buyer names are readable only by admin accounts. Never use a service-role client for ticket operations and never expose names to visitors.
- The grid polls via TanStack Query (`refetchInterval`) instead of realtime subscriptions — keep it that way unless realtime is explicitly requested.
