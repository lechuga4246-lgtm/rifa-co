import { createServerFn } from "@tanstack/react-start";
import { getPublicSupabase, type BoletoPublico } from "./supabase-server";

/** Tablero público: solo número y estado. Los nombres nunca se leen desde aquí. */
export const listBoletos = createServerFn({ method: "GET" }).handler(
  async (): Promise<BoletoPublico[]> => {
    const { data, error } = await getPublicSupabase()
      .from("boletos_tablero")
      .select("numero, estado")
      .order("numero", { ascending: true });
    if (error) throw new Error("No se pudieron cargar los boletos");
    return (data ?? [])
      .filter((b) => b.numero != null && b.estado != null)
      .map((b) => ({
        numero: b.numero as number,
        estado: b.estado as BoletoPublico["estado"],
      }));
  },
);

export const apartarBoleto = createServerFn({ method: "POST" })
  .inputValidator((input: { numero: number; nombre: string }) => {
    const numero = Number(input?.numero);
    const nombre = String(input?.nombre ?? "").trim();
    if (!Number.isInteger(numero) || numero < 1 || numero > 100) {
      throw new Error("Número de boleto inválido");
    }
    if (nombre.length < 2 || nombre.length > 60) {
      throw new Error("Escribe tu nombre (entre 2 y 60 letras)");
    }
    return { numero, nombre };
  })
  .handler(async ({ data }): Promise<{ ok: true } | { ok: false; reason: string }> => {
    // La función de la base solo aparta si el boleto sigue libre.
    const { data: ok, error } = await getPublicSupabase().rpc("apartar_boleto", {
      _numero: data.numero,
      _nombre: data.nombre,
    });
    if (error) return { ok: false, reason: "No se pudo apartar. Inténtalo de nuevo." };
    if (ok !== true) return { ok: false, reason: "Ese boleto ya fue tomado por otra persona." };
    return { ok: true };
  });
