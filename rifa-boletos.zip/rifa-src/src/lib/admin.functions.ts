import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { Boleto } from "./supabase-server";

type Accion = "vendido" | "liberar" | "apartado";

/** Lista completa, con nombres, solo para cuentas administradoras. */
export const listBoletosAdmin = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<Boleto[]> => {
    const { data: admin } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (admin !== true) throw new Error("No tienes permiso");

    const { data, error } = await context.supabase
      .from("boletos")
      .select("numero, estado, nombre")
      .order("numero", { ascending: true });
    if (error) throw new Error("No se pudieron cargar los boletos");
    return (data ?? []) as Boleto[];
  });

export const esAdmin = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    return { admin: data === true };
  });

export const cambiarBoleto = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { numero: number; accion: Accion; nombre?: string | undefined }) => {
    const numero = Number(input?.numero);
    if (!Number.isInteger(numero) || numero < 1 || numero > 100) throw new Error("Número inválido");
    if (!["vendido", "liberar", "apartado"].includes(input?.accion)) throw new Error("Acción inválida");
    const nombre = input?.nombre ? String(input.nombre).trim().slice(0, 60) : undefined;
    return { numero, accion: input.accion, nombre };
  })
  .handler(async ({ data, context }) => {
    const { data: admin } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (admin !== true) throw new Error("No tienes permiso");

    const cambios =
      data.accion === "liberar"
        ? { estado: "libre", nombre: null }
        : { estado: data.accion, ...(data.nombre ? { nombre: data.nombre } : {}) };

    const { error } = await context.supabase
      .from("boletos")
      .update({ ...cambios, actualizado_en: new Date().toISOString() })
      .eq("numero", data.numero);
    if (error) throw new Error("No se pudo guardar el cambio");
    return { ok: true };
  });
