import { createClient, type SupabaseClient } from "@supabase/supabase-js";

export type Boleto = {
  numero: number;
  estado: "libre" | "apartado" | "vendido";
  nombre: string | null;
};

/** Lo que ve quien visita el tablero: número y estado, sin nombre. */
export type BoletoPublico = {
  numero: number;
  estado: Boleto["estado"];
};

let cached: SupabaseClient | null = null;

/** Cliente público de solo lectura/escritura limitada por RLS (rol anon). */
export function getPublicSupabase(): SupabaseClient {
  if (cached) return cached;
  const url = process.env["SUPABASE_URL"]!;
  const key = process.env["SUPABASE_PUBLISHABLE_KEY"]!;
  cached = createClient(url, key, {
    auth: { persistSession: false, autoRefreshToken: false, storage: undefined },
    global: {
      fetch: (input, init) => {
        const h = new Headers(init?.headers);
        if (key.startsWith("sb_") && h.get("Authorization") === `Bearer ${key}`) {
          h.delete("Authorization");
        }
        h.set("apikey", key);
        return fetch(input, { ...init, headers: h });
      },
    },
  });
  return cached;
}
