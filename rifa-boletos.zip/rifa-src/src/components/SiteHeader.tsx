const links = [
  { href: "/#boletos", label: "Boletos" },
  { href: "/#como-participar", label: "Cómo participar" },
  { href: "/#contacto", label: "Contacto" },
] as const;

export function SiteHeader() {
  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-border bg-background/70 backdrop-blur-md">
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
        <a href="/" className="font-display text-2xl tracking-wide">
          Rifa
        </a>
        <ul className="flex gap-6 md:gap-8">
          {links.map((l) => (
            <li key={l.href}>
              <a
                href={l.href}
                className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground transition-colors duration-300 hover:text-foreground md:text-xs"
              >
                {l.label}
              </a>
            </li>
          ))}
        </ul>
      </nav>
    </header>
  );
}
