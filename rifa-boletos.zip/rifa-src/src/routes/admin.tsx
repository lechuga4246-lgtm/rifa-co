import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { cambiarBoleto, esAdmin, listBoletosAdmin } from "@/lib/admin.functions";
import type { Boleto } from "@/lib/supabase-server";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Administrar boletos" },
      { name: "description", content: "Panel privado para marcar boletos de la rifa como pagados." },
      { property: "og:title", content: "Administrar boletos" },
      { property: "og:description", content: "Panel privado de la rifa." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AdminPage,
});

function AdminPage() {
  const [sesion, setSesion] = useState<"cargando" | "fuera" | "dentro">("cargando");

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSesion(data.session ? "dentro" : "fuera"));
    const { data } = supabase.auth.onAuthStateChange((_e, s) => setSesion(s ? "dentro" : "fuera"));
    return () => data.subscription.unsubscribe();
  }, []);

  return (
    <main className="mx-auto min-h-screen max-w-4xl px-6 pb-20 pt-28">
      <p className="text-xs uppercase tracking-[0.25em] text-primary">Panel privado</p>
      <h1 className="mt-2 font-display text-4xl">Administrar boletos</h1>
      {sesion === "cargando" && <p className="mt-8 text-muted-foreground">Cargando…</p>}
      {sesion === "fuera" && <Login />}
      {sesion === "dentro" && <Panel />}
    </main>
  );
}

function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [enviando, setEnviando] = useState(false);

  async function entrar(e: React.FormEvent) {
    e.preventDefault();
    setEnviando(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setEnviando(false);
    if (error) toast.error("Correo o contraseña incorrectos");
  }

  return (
    <form onSubmit={entrar} className="mt-8 max-w-sm space-y-4">
      <input
        type="email"
        required
        placeholder="Correo"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        className="w-full rounded-md border border-border bg-card px-4 py-3 text-foreground outline-none focus:border-primary"
      />
      <input
        type="password"
        required
        placeholder="Contraseña"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        className="w-full rounded-md border border-border bg-card px-4 py-3 text-foreground outline-none focus:border-primary"
      />
      <button
        disabled={enviando}
        className="w-full rounded-md bg-primary px-4 py-3 font-medium text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-50"
      >
        {enviando ? "Entrando…" : "Entrar"}
      </button>
    </form>
  );
}

const etiqueta: Record<Boleto["estado"], string> = {
  libre: "Libre",
  apartado: "Apartado",
  vendido: "Pagado",
};

function Panel() {
  const qc = useQueryClient();
  const checarAdmin = useServerFn(esAdmin);
  const cambiar = useServerFn(cambiarBoleto);
  const [filtro, setFiltro] = useState<"todos" | Boleto["estado"]>("apartado");

  const admin = useQuery({ queryKey: ["es-admin"], queryFn: () => checarAdmin() });
  const boletos = useQuery({
    queryKey: ["boletos"],
    queryFn: () => listBoletosAdmin(),
    refetchInterval: 15_000,
  });

  async function accion(numero: number, a: "vendido" | "liberar" | "apartado", nombre?: string) {
    try {
      await cambiar({ data: { numero, accion: a, nombre } });
      toast.success(`Boleto ${numero} actualizado`);
      qc.invalidateQueries({ queryKey: ["boletos"] });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "No se pudo guardar");
    }
  }

  const salir = (
    <button
      onClick={() => supabase.auth.signOut()}
      className="mt-4 text-sm text-muted-foreground underline-offset-4 hover:text-foreground hover:underline"
    >
      Cerrar sesión
    </button>
  );

  if (admin.isLoading || boletos.isLoading) return <p className="mt-8 text-muted-foreground">Cargando…</p>;
  if (!admin.data?.admin) return <div className="mt-8"><p>Esta cuenta no tiene permiso.</p>{salir}</div>;

  const lista = (boletos.data ?? []).filter((b) => filtro === "todos" || b.estado === filtro);
  const cuenta = (e: Boleto["estado"]) => (boletos.data ?? []).filter((b) => b.estado === e).length;

  return (
    <div className="mt-8">
      <div className="flex flex-wrap gap-2">
        {(["apartado", "vendido", "libre", "todos"] as const).map((f) => (
          <button
            key={f}
            onClick={() => setFiltro(f)}
            className={`rounded-full border px-4 py-1.5 text-sm transition-colors ${
              filtro === f ? "border-primary bg-primary text-primary-foreground" : "border-border text-muted-foreground hover:text-foreground"
            }`}
          >
            {f === "todos" ? "Todos" : `${etiqueta[f]} (${cuenta(f)})`}
          </button>
        ))}
      </div>

      <ul className="mt-6 divide-y divide-border rounded-lg border border-border bg-card">
        {lista.length === 0 && <li className="p-6 text-muted-foreground">No hay boletos aquí.</li>}
        {lista.map((b) => (
          <li key={b.numero} className="flex flex-wrap items-center gap-3 px-4 py-3">
            <span className="w-10 font-display text-xl text-primary">{b.numero}</span>
            <span className="min-w-0 flex-1">
              <span className="block truncate">{b.nombre ?? "—"}</span>
              <span className="text-xs uppercase tracking-wider text-muted-foreground">{etiqueta[b.estado]}</span>
            </span>
            {b.estado !== "vendido" && (
              <button
                onClick={() => {
                  const nombre = b.nombre ?? window.prompt("¿A nombre de quién?")?.trim();
                  if (!nombre) return;
                  accion(b.numero, "vendido", nombre);
                }}
                className="rounded-md bg-primary px-3 py-1.5 text-sm font-medium text-primary-foreground hover:opacity-90"
              >
                Marcar pagado
              </button>
            )}
            {b.estado === "vendido" && (
              <button
                onClick={() => accion(b.numero, "apartado")}
                className="rounded-md border border-border px-3 py-1.5 text-sm hover:border-primary"
              >
                Quitar pago
              </button>
            )}
            {b.estado !== "libre" && (
              <button
                onClick={() => window.confirm(`¿Liberar el boleto ${b.numero}?`) && accion(b.numero, "liberar")}
                className="rounded-md border border-border px-3 py-1.5 text-sm text-muted-foreground hover:text-foreground"
              >
                Liberar
              </button>
            )}
          </li>
        ))}
      </ul>
      {salir}
    </div>
  );
}
