import { createFileRoute } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { toast } from "sonner";
import { listBoletos, apartarBoleto } from "@/lib/boletos.functions";
import type { BoletoPublico } from "@/lib/supabase-server";

const PREMIO = "una tele";
const PRECIO = 15;
const FECHA_SORTEO = "30 de octubre de 2026";

const boletosQuery = queryOptions({
  queryKey: ["boletos"],
  queryFn: () => listBoletos(),
  refetchInterval: 15_000,
});

export const Route = createFileRoute("/")({
  loader: ({ context }) => context.queryClient.ensureQueryData(boletosQuery),
  head: () => ({
    meta: [
      { title: "Rifa de una tele" },
      {
        name: "description",
        content: `Rifa de ${PREMIO}. 100 boletos a $${PRECIO} MXN cada uno. Sorteo el ${FECHA_SORTEO} con ruleta. Aparta tu número dejando tu nombre.`,
      },
      { property: "og:title", content: "Rifa de una tele" },
      {
        property: "og:description",
        content: `100 boletos a $${PRECIO} MXN. Sorteo el ${FECHA_SORTEO}. Aparta el tuyo.`,
      },
    ],
  }),
  component: Rifa,
  errorComponent: ({ error }) => (
    <main className="flex min-h-screen items-center justify-center px-6">
      <p role="alert" className="text-muted-foreground">
        No se pudieron cargar los boletos. {error instanceof Error ? error.message : ""}
      </p>
    </main>
  ),
});

function BoletoCell({ boleto, onSelect }: { boleto: BoletoPublico; onSelect: (n: number) => void }) {
  const base =
    "flex aspect-square items-center justify-center rounded-md text-sm font-medium transition-all duration-300";
  if (boleto.estado === "libre") {
    return (
      <button
        onClick={() => onSelect(boleto.numero)}
        className={`${base} border border-border bg-card text-foreground hover:border-primary hover:bg-accent hover:glow-primary cursor-pointer`}
        aria-label={`Boleto ${boleto.numero}, libre`}
      >
        {boleto.numero}
      </button>
    );
  }
  const vendido = boleto.estado === "vendido";
  return (
    <div
      className={`${base} cursor-not-allowed ${
        vendido
          ? "bg-primary/20 text-primary line-through"
          : "bg-secondary text-muted-foreground"
      }`}
      title={vendido ? "Vendido" : "Apartado"}
      aria-label={`Boleto ${boleto.numero}, ${boleto.estado}`}
    >
      {boleto.numero}
    </div>
  );
}

function Rifa() {
  const { data: boletos } = useSuspenseQuery(boletosQuery);
  const queryClient = useQueryClient();
  const apartar = useServerFn(apartarBoleto);
  const [seleccionado, setSeleccionado] = useState<number | null>(null);
  const [nombre, setNombre] = useState("");
  const [enviando, setEnviando] = useState(false);

  const libres = boletos.filter((b) => b.estado === "libre").length;
  const apartados = boletos.filter((b) => b.estado === "apartado").length;
  const vendidos = boletos.filter((b) => b.estado === "vendido").length;

  async function confirmar() {
    if (seleccionado == null || enviando) return;
    setEnviando(true);
    const res = await apartar({ data: { numero: seleccionado, nombre } });
    setEnviando(false);
    if (res.ok) {
      toast.success(`Boleto ${seleccionado} apartado a nombre de ${nombre.trim()}`);
      setSeleccionado(null);
      setNombre("");
    } else {
      toast.error(res.reason);
    }
    await queryClient.invalidateQueries({ queryKey: ["boletos"] });
  }

  return (
    <main>
      {/* Portada */}
      <section className="relative flex min-h-screen items-center overflow-hidden">
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_top,color-mix(in_oklab,var(--primary)_12%,transparent),transparent_60%)]" />
        <div className="relative mx-auto w-full max-w-6xl px-6 pt-24">
          <p className="rise mt-2 max-w-md text-muted-foreground" style={{ animationDelay: "0.3s" }}>
            100 boletos, un solo ganador. El número se elige con ruleta en vivo.
          </p>
          <div className="rise mt-12 grid max-w-2xl grid-cols-3 gap-px bg-border" style={{ animationDelay: "0.45s" }}>
            <div className="bg-background p-6">
              <p className="text-3xl text-primary md:text-4xl">${PRECIO}</p>
              <p className="mt-1 text-xs uppercase tracking-widest text-muted-foreground">MXN / boleto</p>
            </div>
            <div className="bg-background p-6">
              <p className="text-3xl text-primary md:text-4xl">100</p>
              <p className="mt-1 text-xs uppercase tracking-widest text-muted-foreground">boletos</p>
            </div>
            <div className="bg-background p-6">
              <p className="text-3xl text-primary md:text-4xl">30 oct</p>
              <p className="mt-1 text-xs uppercase tracking-widest text-muted-foreground">sorteo 2026</p>
            </div>
          </div>
          <a
            href="#boletos"
            className="rise mt-12 inline-block rounded-md bg-primary px-8 py-3 text-sm font-semibold uppercase tracking-widest text-primary-foreground transition-transform duration-300 hover:scale-105"
            style={{ animationDelay: "0.6s" }}
          >
            Elige tu número
          </a>
        </div>
      </section>

      {/* Cuadrícula */}
      <section id="boletos" className="mx-auto max-w-6xl scroll-mt-24 px-6 py-24">
        <div className="mb-10 flex flex-wrap items-end justify-between gap-6">
          <div>
            <p className="mb-3 text-xs uppercase tracking-[0.3em] text-primary">Tablero</p>
            <h2 className="text-4xl md:text-5xl">Los 100 boletos</h2>
          </div>
          <div className="flex gap-6 text-xs uppercase tracking-widest text-muted-foreground">
            <span className="flex items-center gap-2">
              <span className="inline-block h-3 w-3 rounded-sm border border-border bg-card" /> {libres} libres
            </span>
            <span className="flex items-center gap-2">
              <span className="inline-block h-3 w-3 rounded-sm bg-secondary" /> {apartados} apartados
            </span>
            <span className="flex items-center gap-2">
              <span className="inline-block h-3 w-3 rounded-sm bg-primary/30" /> {vendidos} vendidos
            </span>
          </div>
        </div>

        <div className="grid grid-cols-5 gap-2 sm:grid-cols-10">
          {boletos.map((b) => (
            <BoletoCell key={b.numero} boleto={b} onSelect={setSeleccionado} />
          ))}
        </div>

        {seleccionado != null && (
          <div className="rise mt-8 max-w-md rounded-lg border border-primary/40 bg-card p-6 glow-primary">
            <p className="text-sm text-muted-foreground">
              Vas a apartar el boleto <span className="font-display text-2xl text-primary">#{seleccionado}</span>
            </p>
            <label htmlFor="nombre" className="mt-4 block text-xs uppercase tracking-widest text-muted-foreground">
              Tu nombre
            </label>
            <input
              id="nombre"
              value={nombre}
              onChange={(e) => setNombre(e.target.value)}
              maxLength={60}
              placeholder="Ej. Miguel Lechuga"
              className="mt-2 w-full rounded-md border border-input bg-background px-4 py-2 text-foreground outline-none focus:border-primary"
            />
            <div className="mt-4 flex gap-3">
              <button
                onClick={confirmar}
                disabled={enviando || nombre.trim().length < 2}
                className="rounded-md bg-primary px-6 py-2 text-sm font-semibold text-primary-foreground transition-opacity disabled:opacity-40"
              >
                {enviando ? "Apartando…" : "Apartar boleto"}
              </button>
              <button
                onClick={() => setSeleccionado(null)}
                className="rounded-md border border-border px-6 py-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
              >
                Cancelar
              </button>
            </div>
            <p className="mt-4 text-xs text-muted-foreground">
              El pago (${PRECIO} MXN) se arregla por teléfono. Tu boleto queda apartado de inmediato.
            </p>
          </div>
        )}
      </section>

      {/* Cómo participar */}
      <section id="como-participar" className="scroll-mt-24 border-y border-border bg-card/40">
        <div className="mx-auto max-w-6xl px-6 py-24">
          <p className="mb-3 text-xs uppercase tracking-[0.3em] text-primary">Paso a paso</p>
          <h2 className="text-4xl md:text-5xl">Cómo participar</h2>
          <ol className="mt-12 grid gap-px bg-border md:grid-cols-3">
            {[
              { n: "01", t: "Elige tu número", d: "Toca cualquier boleto libre del tablero y escribe tu nombre para apartarlo." },
              { n: "02", t: "Paga por teléfono", d: `El pago de tus $${PRECIO} MXN por boleto se arregla por teléfono en cuanto lo apartas.` },
              { n: "03", t: "Espera la ruleta", d: `El ${FECHA_SORTEO} giramos la ruleta en vivo y el número ganador se lleva ${PREMIO}.` },
            ].map((p) => (
              <li key={p.n} className="bg-background p-8">
                <span className="text-xs text-primary">{p.n}</span>
                <h3 className="mt-3 text-2xl">{p.t}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{p.d}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      {/* Contacto */}
      <section id="contacto" className="mx-auto max-w-6xl scroll-mt-24 px-6 py-24 text-center">
        <p className="mb-3 text-xs uppercase tracking-[0.3em] text-primary">Contacto</p>
        <h2 className="text-4xl md:text-5xl">¿Dudas o quieres pagar?</h2>
        <p className="mx-auto mt-6 max-w-md text-muted-foreground">
          El pago se arregla por teléfono en cuanto apartas tu número.
        </p>
      </section>

      <footer className="border-t border-border py-8 text-center text-xs text-muted-foreground">
        Sorteo el {FECHA_SORTEO} · Número ganador por ruleta
      </footer>
    </main>
  );
}
