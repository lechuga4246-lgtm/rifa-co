-- Rifa zato-draw: tabla de boletos (100 boletos, 1-100, estado libre por defecto)
CREATE TABLE public.boletos (
  numero integer PRIMARY KEY CHECK (numero BETWEEN 1 AND 100),
  estado text NOT NULL DEFAULT 'libre' CHECK (estado IN ('libre', 'apartado', 'vendido')),
  nombre text,
  actualizado_en timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, UPDATE ON public.boletos TO anon;
GRANT SELECT, UPDATE ON public.boletos TO authenticated;
GRANT ALL ON public.boletos TO service_role;

ALTER TABLE public.boletos ENABLE ROW LEVEL SECURITY;

-- Cualquiera puede ver la cuadrícula (sin exponer nombres en la app; la política permite leer la fila)
CREATE POLICY "boletos_select_public" ON public.boletos
  FOR SELECT TO anon, authenticated
  USING (true);

-- Apartar: solo si el boleto sigue libre y se deja un nombre
CREATE POLICY "boletos_apartar_public" ON public.boletos
  FOR UPDATE TO anon, authenticated
  USING (estado = 'libre')
  WITH CHECK (estado = 'apartado' AND nombre IS NOT NULL AND length(btrim(nombre)) BETWEEN 2 AND 60);

-- Sembrar los 100 boletos, todos libres
INSERT INTO public.boletos (numero)
SELECT generate_series(1, 100);
