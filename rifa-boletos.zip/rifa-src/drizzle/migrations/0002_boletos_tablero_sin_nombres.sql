-- El tablero público solo muestra números y estado, nunca nombres.
CREATE VIEW public.boletos_tablero AS
  SELECT numero, estado FROM public.boletos;

GRANT SELECT ON public.boletos_tablero TO anon, authenticated;
GRANT ALL ON public.boletos_tablero TO service_role;

-- Los nombres solo los leen las cuentas administradoras.
DROP POLICY IF EXISTS "boletos_select_public" ON public.boletos;
CREATE POLICY "boletos_select_admin" ON public.boletos
  FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

REVOKE SELECT ON public.boletos FROM anon;

-- Apartar un boleto libre de forma atómica, sin exponer nombres.
CREATE OR REPLACE FUNCTION public.apartar_boleto(_numero integer, _nombre text)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  afectadas integer;
BEGIN
  IF _numero IS NULL OR _numero < 1 OR _numero > 100 THEN
    RETURN false;
  END IF;
  IF _nombre IS NULL OR length(btrim(_nombre)) < 2 OR length(btrim(_nombre)) > 60 THEN
    RETURN false;
  END IF;

  UPDATE public.boletos
     SET estado = 'apartado',
         nombre = btrim(_nombre),
         actualizado_en = now()
   WHERE numero = _numero
     AND estado = 'libre';

  GET DIAGNOSTICS afectadas = ROW_COUNT;
  RETURN afectadas > 0;
END;
$$;

GRANT EXECUTE ON FUNCTION public.apartar_boleto(integer, text) TO anon, authenticated;